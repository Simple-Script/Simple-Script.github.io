import PyInstaller.__main__
import os
import sys
from tkinter import Tk, filedialog, messagebox
import tkinter as tk
from tkinter import ttk

class ConverterGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Python to EXE Converter")
        self.root.geometry("500x300")
        
        # Create main frame
        main_frame = ttk.Frame(root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # File selection
        ttk.Label(main_frame, text="Python File:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.file_path = tk.StringVar()
        self.file_entry = ttk.Entry(main_frame, textvariable=self.file_path, width=50)
        self.file_entry.grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(main_frame, text="Browse", command=self.browse_file).grid(row=0, column=2, pady=5)
        
        # Options
        options_frame = ttk.LabelFrame(main_frame, text="Options", padding="5")
        options_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)
        
        self.console_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(options_frame, text="Console Window", variable=self.console_var).grid(row=0, column=0, sticky=tk.W)
        
        self.icon_path = tk.StringVar()
        ttk.Label(options_frame, text="Icon (optional):").grid(row=1, column=0, sticky=tk.W, pady=5)
        ttk.Entry(options_frame, textvariable=self.icon_path, width=40).grid(row=1, column=1, padx=5, pady=5)
        ttk.Button(options_frame, text="Browse", command=self.browse_icon).grid(row=1, column=2, pady=5)
        
        # Convert button
        ttk.Button(main_frame, text="Convert to EXE", command=self.convert).grid(row=2, column=0, columnspan=3, pady=20)
        
        # Progress
        self.progress_var = tk.StringVar(value="Ready")
        ttk.Label(main_frame, textvariable=self.progress_var).grid(row=3, column=0, columnspan=3)
        
    def browse_file(self):
        filename = filedialog.askopenfilename(filetypes=[("Python Files", "*.py")])
        if filename:
            self.file_path.set(filename)
            
    def browse_icon(self):
        filename = filedialog.askopenfilename(filetypes=[("Icon Files", "*.ico")])
        if filename:
            self.icon_path.set(filename)
            
    def convert(self):
        if not self.file_path.get():
            messagebox.showerror("Error", "Please select a Python file")
            return
            
        try:
            self.progress_var.set("Converting... Please wait")
            self.root.update()
            
            args = [
                self.file_path.get(),
                '--onefile',
                '--name=' + os.path.splitext(os.path.basename(self.file_path.get()))[0]
            ]
            
            if not self.console_var.get():
                args.append('--noconsole')
                
            if self.icon_path.get():
                args.append('--icon=' + self.icon_path.get())
                
            PyInstaller.__main__.run(args)
            
            self.progress_var.set("Conversion complete! EXE created in 'dist' folder")
            messagebox.showinfo("Success", "EXE file has been created in the 'dist' folder!")
            
        except Exception as e:
            self.progress_var.set("Error during conversion")
            messagebox.showerror("Error", str(e))

if __name__ == "__main__":
    root = Tk()
    app = ConverterGUI(root)
    root.mainloop()
